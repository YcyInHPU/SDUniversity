# -*- coding: UTF-8 -*- #
"""
@filename:preprocess_water_characteristic.py
@author:Chunyu Yuan
@time:2024-11-04
"""
import pandas as pd
import numpy as np
import os
import shutil
import argparse
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

def copy_image(src_folder, dest_folder, image_name):
    # 判断源文件夹是否存在
    if not os.path.exists(src_folder):
        print("源文件夹不存在，请检查路径。")
        return

    # 构造源文件的完整路径
    # src_image_path = os.path.join(src_folder, image_name)
    dest_folder_name = os.path.join(dest_folder, image_name)
    # 检查源文件是否存在
    if os.path.exists(src_folder):
        # 复制文件到目标文件夹
        shutil.copy(src_folder, dest_folder_name)
        # print(f"成功复制 {image_name} 到 {dest_folder}")
    else:
        print("图片未找到，请输入有效的文件名。")


def parse_args():
    parser = argparse.ArgumentParser(description='Run Task with specified options.')
    parser.add_argument('--input_path', default='Water_pollution_characteristic/Input', type=str)
    parser.add_argument('--output_path', default='Water_pollution_characteristic/Output', type=str)
    parser.add_argument('--Province', default='山东省', type=str)
    parser.add_argument('--Basin2', default='沂沭泗流域', type=str)
    parser.add_argument('--Basin3', default='湖西区', type=str)
    parser.add_argument('--WQParams', default='有色可溶性有机物CDOM', type=str)
    parser.add_argument('--Institution', default='山东大学', type=str)
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    print("run...")
    # 读取数据
    # input_path = r'E:\XM\20240806HTHT\水质特征图谱\Input'
    # output_path = r'E:\XM\20240806HTHT\水质特征图谱\Output'
    # Province = '山东省'
    # Basin2 = '沂沭泗流域'
    # Basin3 = '湖西区'
    # WQParams = '有色可溶性有机物CDOM'
    # Institution = '山东大学'
    # Site_Name = '105公路桥'

    args = parse_args()
    input_path = args.input_path
    output_path = args.output_path
    Province = args.Province
    Basin2 = args.Basin2
    Basin3 = args.Basin3
    WQParams = args.WQParams
    Institution = args.Institution

    try:
        # 输入源文件夹路径和目标文件夹路径
        image_src_folder = input_path + '/' + WQParams + '.jpg'
        # 输入图片文件名
        image_name = Province + Basin2 + Basin3 + '_' + WQParams + '_特征图谱.jpg'

        table_src_folder = input_path + '/' + WQParams + '.xlsx'
        # 输入表格文件名
        table_name = Province + Basin2 + Basin3 + '_' + WQParams + '_光谱特征.xlsx'
        # 调用函数进行复制
        copy_image(image_src_folder, output_path, image_name)
        copy_image(table_src_folder, output_path, table_name)

    except FileNotFoundError:
        print("文件未找到，请检查文件名和路径，或上传数据!")
    except Exception as e:
        print(f"发生错误：{e}")